﻿using System;
using VkNet;
using VkNet.Model;
using System.Threading.Tasks;

namespace BanRozigrish
{
    class Program
    {
        static void Main(string[] args)
        {
            VkApi vkApi = new VkApi();

            vkApi.Authorize(new ApiAuthParams
            {
                AccessToken = "0a67b1378e6d5b8b999ffc42e51f14235c54f6cc17793dcd06d3ba91d0d445ee39d84e6e59b8c5230c076"
            });

           

                var messages = vkApi.Messages.GetHistory(new VkNet.Model.RequestParams.MessagesGetHistoryParams
                {
                    PeerId = 2000000000 + 58
                });
                long lastMess = 0;
                foreach(Message i in messages.Messages)
                {
                    if (i.Text == "Розыгрыш бана" && Convert.ToInt32(i.Id) != lastMess)
                    {
                    lastMess = Convert.ToInt32(i.Id);
                    Console.WriteLine("Сработало");

                    }
                     else
                     {
                    break;
                     }
                }
                //if(messages.Messages.ToString().Contains("Розыгрыш бана"))
                //{
                //    Console.WriteLine("Розыгрыш бана");
                //}
                Task.Delay(1000);
        }
    }
}
